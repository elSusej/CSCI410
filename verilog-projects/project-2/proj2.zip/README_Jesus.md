Name: Jesus Ledezma
References: Google's AI Overview (used to brush up on verilog syntax)
Time Spent: ~3 hours
Notes: Drawing out all the hardware that makes up this simple ALU was fun. Figuring out how to get zr and ng was also a fun thought exercise. 