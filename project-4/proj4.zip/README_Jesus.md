Name: Jesus Ledezma
References: Chat GPT (used for hack assembly syntax)
Time Spent: ~8 hours
Notes: y autograder no worky man